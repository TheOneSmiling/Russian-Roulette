Remember to type in if you want to activate cheat mode or not, or else the game will crash

Made by thatnooboscar on Discord
